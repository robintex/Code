import React, { useState, useRef, useEffect } from "react";

const App = () => {
  const canvasRef = useRef(null);
  const [ball, setBall] = useState({ x: 150, y: 150, vx: 0, vy: 0, moving: false });
  const [instructions, setInstructions] = useState(true);

  const canvasWidth = window.innerWidth-30;
  const canvasHeight =window.innerHeight-50;
  const friction =0.98; 
  const speed = 30;
  const ballRadius = 15;

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");

    const drawBall = () => {
      ctx.clearRect(0, 0, canvasWidth, canvasHeight);
      ctx.fillStyle = "#2563eb"; 
      ctx.beginPath();
      ctx.arc(ball.x, ball.y, ballRadius, 0, Math.PI * 2);
      ctx.fill();
      ctx.closePath();
    };

    const moveBall = () => {
      if (!ball.moving) return;

      let { x, y, vx, vy } = ball;

      x += vx;
      y += vy;

      if (x + ballRadius > canvasWidth || x - ballRadius < 0) {
        vx = -vx;
        x = x + ballRadius > canvasWidth ? canvasWidth - ballRadius : ballRadius;
      }
      if (y + ballRadius > canvasHeight || y - ballRadius < 0) {
        vy = -vy;
        y = y + ballRadius > canvasHeight ? canvasHeight - ballRadius : ballRadius;
      }
      vx *= friction;
      vy *= friction;
      if (Math.abs(vx) < 0.1 && Math.abs(vy) < 0.1) {
        vx = 0;
        vy = 0;
        setInstructions(true);
        setBall((prev) => ({ ...prev, moving: false }));
      }

      setBall((prev) => ({ ...prev, x, y, vx, vy }));
    };

    const animationFrame = setInterval(() => {
      drawBall();
      moveBall();
    }, 16); 

    return () => clearInterval(animationFrame);
  }, [ball]);

  const handleCanvasClick = (e) => {
    if (ball.moving) return;

    const rect = canvasRef.current.getBoundingClientRect();
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;

    const angle = Math.atan2(mouseY - ball.y, mouseX - ball.x);

    setBall({
      x: ball.x,
      y: ball.y,
      vx: speed * Math.cos(angle),
      vy: speed * Math.sin(angle),
      moving: true,
    });

    setInstructions(false);
  };

  return (
<div className="w-full h-auto flex justify-center items-center border-green-500">
 
  {!ball.moving && (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100">
      Click Here to start
    </div>
  )}

  <canvas
    ref={canvasRef}
    width={canvasWidth}
    height={canvasHeight}
    className="border bg-white p-10"
    onClick={handleCanvasClick}
  />
</div>

   
  );
};

export default App;
