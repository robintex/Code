import React, { useState, useRef } from "react";
import "./App.css";

function App() {
  const [blocks, setBlocks] = useState([
    { id: 0, x: getRandomPosition().x, y: getRandomPosition().y, parent: null },
  ]);

  const [draggingId, setDraggingId] = useState(null);
  const offset = useRef({ x: 0, y: 0 });

  function getRandomPosition() {
    return {
      x: Math.floor(Math.random() * window.innerWidth * 0.8),
      y: Math.floor(Math.random() * window.innerHeight * 0.8),
    };
  }

  
  const addBlock = (parentId) => {
    const position = getRandomPosition();
    setBlocks((prev) => [
      ...prev,
      { id: prev.length, x: position.x, y: position.y, parent: parentId },
    ]);
  };

  
  const handleMouseDown = (e, id) => {
    e.stopPropagation();
    setDraggingId(id);
    offset.current = {
      x: e.clientX - blocks.find((block) => block.id === id).x,
      y: e.clientY - blocks.find((block) => block.id === id).y,
    };
  };

  
  const handleMouseMove = (e) => {
    if (draggingId !== null) {
      const newX = e.clientX - offset.current.x;
      const newY = e.clientY - offset.current.y;
      setBlocks((prev) =>
        prev.map((block) =>
          block.id === draggingId ? { ...block, x: newX, y: newY } : block
        )
      );
    }
  };

  
  const handleMouseUp = () => {
    setDraggingId(null);
  };

  return (
    <div
      className="w-full h-screen bg-pink-100 relative overflow-hidden"
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
    >
      {blocks.map((block) => (
        <React.Fragment key={block.id}>
          {}
          {block.parent !== null && (
            <svg
              className="absolute top-0 left-0 w-full h-full pointer-events-none"
            >
              <line
                x1={blocks[block.parent].x + 50}
                y1={blocks[block.parent].y + 50}
                x2={block.x + 50}
                y2={block.y + 50}
                stroke="black"
                strokeWidth="2"
                strokeDasharray="5,5"
              />
            </svg>
          )}
          {}
          <div
            className="absolute w-20 h-20 bg-pink-500 rounded-lg flex items-center justify-center text-white shadow-lg cursor-grab active:cursor-grabbing"
            style={{ top: `${block.y}px`, left: `${block.x}px` }}
            onMouseDown={(e) => handleMouseDown(e, block.id)}
          >
            <div className="flex flex-col items-center">
              <span>{block.id}</span>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  addBlock(block.id);
                }}
                className="bg-pink-300 text-pink-900 px-2 py-1 rounded mt-2"
              >
                +
              </button>
            </div>
          </div>
        </React.Fragment>
      ))}
    </div>
  );
}

export default App;
