import React, { createContext, useState } from "react";

// Create context
const PartitionContext = createContext();

// Context provider
export const PartitionProvider = ({ children }) => {
  const [partitions, setPartitions] = useState([
    { id: 1, color: getRandomColor(), children: [], parent: null },
  ]);

  // Generate a random color
  function getRandomColor() {
    const letters = "0123456789ABCDEF";
    let color = "#";
    for (let i = 0; i < 6; i++) {
      color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
  }

  // Split a partition
  const splitPartition = (id, type) => {
    setPartitions((prev) =>
      prev.map((partition) =>
        partition.id === id
          ? {
              ...partition,
              children: [
                { id: Date.now(), color: partition.color, children: [], parent: id },
                { id: Date.now() + 1, color: getRandomColor(), children: [], parent: id },
              ],
              split: type,
            }
          : partition
      )
    );
  };

  // Remove a partition
  const removePartition = (id) => {
    setPartitions((prev) =>
      prev.filter((partition) => partition.id !== id)
    );
  };

  return (
    <PartitionContext.Provider
      value={{ partitions, splitPartition, removePartition }}
    >
      {children}
    </PartitionContext.Provider>
  );
};

export default PartitionContext;
