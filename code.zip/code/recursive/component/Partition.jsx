import React, { useContext } from "react";
import PartitionContext from "../context/PartitionContext";
import Resizable from "./Resizable";

const Partition = ({ partition }) => {
  const { splitPartition, removePartition } = useContext(PartitionContext);

  // If partition is undefined, return null to prevent errors
  if (!partition) return null;

  if (partition.children.length > 0) {
    return (
      <div
        className={`flex ${
          partition.split === "v" ? "flex-row" : "flex-col"
        } h-full w-full`}
      >
        {partition.children.map((child) => (
          <Resizable key={child.id}>
            <Partition partition={child} />
          </Resizable>
        ))}
      </div>
    );
  }

  return (
    <div
      className="relative flex items-center justify-center"
      style={{ backgroundColor: partition.color }}
    >
      <div className="absolute top-2 right-2 space-x-2">
        <button
          className="bg-blue-500 text-white px-2 py-1 rounded"
          onClick={() => splitPartition(partition.id, "v")}
        >
          V
        </button>
        <button
          className="bg-green-500 text-white px-2 py-1 rounded"
          onClick={() => splitPartition(partition.id, "h")}
        >
          H
        </button>
        <button
          className="bg-red-500 text-white px-2 py-1 rounded"
          onClick={() => removePartition(partition.id)}
        >
          -
        </button>
      </div>
    </div>
  );
};

export default Partition;
