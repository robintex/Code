import React, { useRef, useState } from "react";

const Resizable = ({ children }) => {
  const containerRef = useRef();
  const [isResizing, setIsResizing] = useState(false);

  const handleMouseDown = (e) => {
    setIsResizing(true);
    document.body.style.cursor = "col-resize";
    e.preventDefault();
  };

  const handleMouseMove = (e) => {
    if (isResizing && containerRef.current) {
      const rect = containerRef.current.getBoundingClientRect();
      containerRef.current.style.width = `${e.clientX - rect.left}px`;
    }
  };

  const handleMouseUp = () => {
    setIsResizing(false);
    document.body.style.cursor = "default";
  };

  return (
    <div
      ref={containerRef}
      className="relative flex-grow border"
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
    >
      {children}
      <div
        className="absolute top-0 right-0 h-full w-2 cursor-col-resize"
        onMouseDown={handleMouseDown}
      ></div>
    </div>
  );
};

export default Resizable;
