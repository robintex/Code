import React, { useContext } from "react";
import { PartitionProvider } from "./context/PartitionContext";
import PartitionContext from "./context/PartitionContext";
import Partition from "./component/Partition";

function App() {
  const RootPartition = () => {
    const { partitions } = useContext(PartitionContext);

    // Get the root partition (first one in the list)
    const rootPartition = partitions[0];

    // Ensure the root partition exists
    if (!rootPartition) return null;

    return <Partition partition={rootPartition} />;
  };

  return (
    <PartitionProvider>
      <div className="w-screen h-screen">
        <RootPartition />
      </div>
    </PartitionProvider>
  );
}

export default App;
